package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLoginAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootLoginAppApplication.class, args);
	}

}
